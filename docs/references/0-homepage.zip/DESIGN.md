---
name: Orbital Intelligence
colors:
  surface: '#101319'
  surface-dim: '#101319'
  surface-bright: '#36393f'
  surface-container-lowest: '#0b0e13'
  surface-container-low: '#191c21'
  surface-container: '#1d2025'
  surface-container-high: '#272a2f'
  surface-container-highest: '#32353a'
  on-surface: '#e1e2e9'
  on-surface-variant: '#bbc9ce'
  inverse-surface: '#e1e2e9'
  inverse-on-surface: '#2e3036'
  outline: '#869398'
  outline-variant: '#3c494d'
  surface-tint: '#33d7fd'
  primary: '#b5edff'
  on-primary: '#003641'
  primary-container: '#36d9ff'
  on-primary-container: '#005c6e'
  inverse-primary: '#00677c'
  secondary: '#75dc85'
  on-secondary: '#003913'
  secondary-container: '#007c32'
  on-secondary-container: '#aeffb4'
  tertiary: '#fadaff'
  on-tertiary: '#53006f'
  tertiary-container: '#eeb3ff'
  on-tertiary-container: '#8711b1'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#b1ecff'
  primary-fixed-dim: '#33d7fd'
  on-primary-fixed: '#001f27'
  on-primary-fixed-variant: '#004e5e'
  secondary-fixed: '#91f99e'
  secondary-fixed-dim: '#75dc85'
  on-secondary-fixed: '#002108'
  on-secondary-fixed-variant: '#00531f'
  tertiary-fixed: '#f9d8ff'
  tertiary-fixed-dim: '#eeb1ff'
  on-tertiary-fixed: '#330045'
  on-tertiary-fixed-variant: '#76009c'
  background: '#101319'
  on-background: '#e1e2e9'
  surface-variant: '#32353a'
  panel-graphite: '#181D24'
  surface-white: '#F7F8FA'
  event-amber: '#FFB65C'
  data-muted: '#8B8B9E'
  brand-accent: '#6359E9'
typography:
  display-lg:
    fontFamily: Space Grotesk
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: 0.08em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 32px
  panel-padding: 24px
  max-width: 1440px
---

## Brand & Style

This design system is engineered for high-stakes business networking and AI-augmented event management. The brand personality is authoritative, technical, and forward-leaning—evoking the feeling of a "Command Center" for professional growth. It prioritizes information density without sacrificing clarity, utilizing a "Technical Modernism" aesthetic.

The visual style blends **Minimalism** with subtle **Glassmorphism**. Surfaces are treated as physical panels in a digital cockpit, utilizing dark mode by default to reduce eye strain during long-form data analysis and event coordination. The atmosphere is quiet, intelligent, and premium, favoring precision over decoration to build high trust with executive users.

## Colors

The palette is anchored in a "Deep Space" environment. The primary background is `#101318`, providing a high-contrast foundation for vibrant functional signals. 

- **Primary (Signal Cyan):** Reserved for interactive states, primary actions, and AI-driven insights. It represents the "active" pulse of the system.
- **Secondary (Match Green):** Specifically used for networking compatibility, success states, and confirmed event registrations.
- **Tertiary (Relation Magenta):** Dedicated to interpersonal connections, messaging, and networking "sparks."
- **Event Amber:** A functional accent for schedules, upcoming deadlines, and time-sensitive alerts.
- **Panel Graphite:** Used to create layered hierarchy, separating the main navigation and content containers from the base canvas.

## Typography

The typographic system utilizes a tri-font strategy to balance character with utility.

1.  **Display (Space Grotesk):** Used for headlines and section titles. Its geometric, slightly technical quirks emphasize the AI-driven nature of the product.
2.  **Body (Inter):** The workhorse for all long-form text, profile descriptions, and event details. It is chosen for its exceptional legibility at small sizes.
3.  **Mono (JetBrains Mono):** Used for metadata, timestamps, networking IDs, and status labels. This reinforces the "Command Center" aesthetic and assists in scanning dense data tables.

All uppercase styling should be reserved for `label` roles to maintain the technical tone without feeling aggressive.

## Layout & Spacing

The layout is built on a **12-column fluid grid** with a fixed maximum width of 1440px to ensure readability on ultra-wide monitors. 

- **Spacing Rhythm:** Based on a 4px baseline grid. Internal component padding should follow `unit * 2` (8px) or `unit * 4` (16px) increments.
- **Breakpoints:** 
    - Mobile (< 768px): 4-column grid, 16px margins.
    - Tablet (768px - 1024px): 8-column grid, 24px margins.
    - Desktop (> 1024px): 12-column grid, 32px margins.
- **Data Density:** In dashboards, use tighter vertical spacing for lists and tables to allow users to see more information at once, utilizing the `body-sm` and `label-sm` levels.

## Elevation & Depth

This design system avoids traditional heavy shadows in favor of **Tonal Layering** and **Subtle Glassmorphism**.

- **Level 0 (Canvas):** `#101318`. The base surface.
- **Level 1 (Panels):** `#181D24`. Primary containers for content modules. These feature a 1px border of `#FFFFFF` at 5-10% opacity to define edges.
- **Level 2 (Overlays/Modals):** A semi-transparent blur (Backdrop Filter: 12px) over the Panel color. This creates a sense of transient importance.
- **Interactions:** Hover states on interactive elements should use a subtle outer glow (0px 0px 8px) using the Primary Signal Cyan at 20% opacity, rather than a shadow, to simulate a screen's light emission.

## Shapes

The shape language is disciplined and professional. We use a **Soft (4px - 8px)** approach to maintain a technical edge while ensuring the interface feels modern.

- **Standard Elements:** 4px radius (inputs, buttons, chips).
- **Large Containers:** 8px radius (cards, panels, modals).
- **Strict Adherence:** Never exceed 8px. Rounded-pill shapes are permitted only for status "badges" where the height is less than 24px.
- **Dividers:** Horizontal and vertical lines should be 1px, using `#F7F8FA` at 10% opacity.

## Components

- **Buttons:** Primary buttons use a solid Signal Cyan background with black text. Secondary buttons use a transparent background with a 1px Cyan border. Ghost buttons use Mono text with no border.
- **Chips & Badges:** Used extensively for "Interests" or "Tech Stack" tags. These should use the Mono font and a subtle background tint of the relevant category color (Green for matches, Amber for time).
- **Input Fields:** Dark Graphite background, 1px subtle border. On focus, the border transitions to Signal Cyan with a faint outer glow.
- **Cards:** No external shadows. Use the Level 1 Panel color with a defined 1px border. Card headers should use Space Grotesk in Medium weight.
- **Networking Lists:** Rows should be separated by 1px dividers. Use a "Hover Row" state that slightly lightens the background to `#1F242C`.
- **AI Insight Module:** A special component with a very subtle Magenta-to-Cyan gradient border (2px) to signify "Smart" content generated by the system.